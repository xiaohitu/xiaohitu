package com.etc.flowershop.dto;

public class FlowerKind {
	private int KindId;
	private String Name;
	private String Note;
	public int getKindId() {
		return KindId;
	}
	public void setKindId(int kindId) {
		KindId = kindId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getNote() {
		return Note;
	}
	public void setNote(String note) {
		Note = note;
	}
	
}

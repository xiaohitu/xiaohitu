package com.etc.flowershop.dto;

public class PayMent {
	private int PayMethodId;
	private String Name;
	private String Note;
	public int getPayMethodId() {
		return PayMethodId;
	}
	public void setPayMethodId(int payMethodId) {
		PayMethodId = payMethodId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getNote() {
		return Note;
	}
	public void setNote(String note) {
		Note = note;
	}
	
	
}

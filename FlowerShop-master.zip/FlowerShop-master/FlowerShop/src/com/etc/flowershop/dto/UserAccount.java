package com.etc.flowershop.dto;

public class UserAccount {

	private int Aid;
	private float Account;
	private int Uid;
	public int getAid() {
		return Aid;
	}
	public void setAid(int aid) {
		Aid = aid;
	}
	public float getAccount() {
		return Account;
	}
	public void setAccount(float account) {
		Account = account;
	}
	public int getUid() {
		return Uid;
	}
	public void setUid(int uid) {
		Uid = uid;
	}
	
}

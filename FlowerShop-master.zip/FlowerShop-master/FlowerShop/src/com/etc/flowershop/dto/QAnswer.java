package com.etc.flowershop.dto;

public class QAnswer {
	private int QId;
	private String QInfo;
	private String QAnswer;
	private String Note;
	public int getQId() {
		return QId;
	}
	public void setQId(int qId) {
		QId = qId;
	}
	public String getQInfo() {
		return QInfo;
	}
	public void setQInfo(String qInfo) {
		QInfo = qInfo;
	}
	public String getQAnswer() {
		return QAnswer;
	}
	public void setQAnswer(String qAnswer) {
		QAnswer = qAnswer;
	}
	public String getNote() {
		return Note;
	}
	public void setNote(String note) {
		Note = note;
	}
	
}

$(document).ready(function(){

	$.get('http://download.templatemo.com/themes/log?id='+672066+'&oi='+396+'&ot=1&&url='+window.location, function(json){})    

});